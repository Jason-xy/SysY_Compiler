// And is prior to or
int main () {
    int a;
    int b;
    int c;
    int d;
    a = 3;
    b = 8;
    c = -4;
    d = 15;
    int t;
    if (d % (b - a) != 0 && a > 0 || d % 3 == 0 && c > 0) {
        t = d + c - -b;
        putint(t);
    }
    return 0;
}
