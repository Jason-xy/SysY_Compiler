int a;
int b;
int main(){
	a = 10;
	b = 3;
	int c;
	c = a % b;
	return c;
}
