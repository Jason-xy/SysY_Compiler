int a;
int b;
int main(){
	a=10;
	int c;
	c=10;
	return 0;
}
