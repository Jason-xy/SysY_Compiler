int a;
int b;

int main(){
	a=10;
	b=20;
	int c;
	c = a + b;
	return c;
}
