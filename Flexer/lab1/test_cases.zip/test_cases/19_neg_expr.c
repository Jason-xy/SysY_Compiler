int a;
int b;
int main(){
	a = getint();
	b = getint();
	int c;
	c = -(a + b);
                putint(c);
	return 0;
}
