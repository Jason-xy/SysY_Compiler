int a=5;
int s[10]={0,1,2,3,4,5,6,7,8,9};

int main(){
    int i=0;
    while(s[i]<=a){
        i=i+1;
    }
    return i;
}