int a,b,c;

void add(int a,int b){
    c=a+b;
    return;
}

int main(){
    a=3;
    b=2;
    add(a,b);
    return c;
}