int main(){
    int a=10;
    while(a>0){
        if(a>5){
            a=a-1;
            continue;
        }
        return a;
    }
    return a;
}