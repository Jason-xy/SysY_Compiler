int a[10];
int main(){
	a[0]=1;
	return 0;
}
