int main(){
    //this is a single line comment
    //int a;
    //a=5;
    return 0;
}