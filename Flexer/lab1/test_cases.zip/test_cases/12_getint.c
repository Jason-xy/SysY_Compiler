int main(){
	int a;
	a = getint();
	return a;
}
